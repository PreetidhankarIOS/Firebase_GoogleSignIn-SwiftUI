//
//  LoginWithGoogleApp.swift
//  LoginWithGoogle
//
//  Created by Ashish Viltoriya on 30/12/23.
//

import SwiftUI


@main
struct LoginWithGoogleApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    @StateObject var userAuth: UserAuthModel =  UserAuthModel()
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .environmentObject(userAuth)
        
    }
}
