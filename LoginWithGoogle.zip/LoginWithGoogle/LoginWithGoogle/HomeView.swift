//
//  HomeView.swift
//  LoginWithGoogle
//
//  Created by Ashish Viltoriya on 02/01/24.
//

import SwiftUI

struct HomeView: View {
    
    var body: some View {
        
        VStack {
                HStack(spacing: 15) {
                    Text("Sign in with Google")
                        .modifier(CustomTextM(fontName: "NunitoSans-Bold", fontSize: 16, fontColor: Color.black))
                    
                }
            
            .modifier(SFButton())
            .background(Color.gray)
            .cornerRadius(50.0)
            .padding(.bottom,0)
            
            
            
        }
        .padding()
    }
}

#Preview {
    HomeView()
}
