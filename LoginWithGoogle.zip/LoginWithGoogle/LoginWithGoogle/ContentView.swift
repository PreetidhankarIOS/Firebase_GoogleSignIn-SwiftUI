//
//  ContentView.swift
//  LoginWithGoogle
//
//  Created by Ashish Viltoriya on 30/12/23.
//

import SwiftUI


struct ContentView: View {
    @EnvironmentObject var vm: UserAuthModel
    var body: some View {
        
        VStack {
            Button(action: {
                Task {
                    await vm.signIn()
                }
            }){
                HStack(spacing: 15) {
                    Image("google_icon")
                        .renderingMode(.original)
                        .resizable()
                        .frame(width: 25, height: 25)
                        .padding(.leading, 85)
                    Text("Sign in with Google")
                        .modifier(CustomTextM(fontName: "NunitoSans-Bold", fontSize: 16, fontColor: Color.black))
                    Spacer()
                }}
            
            .modifier(SFButton())
            .background(Color.gray)
            .cornerRadius(50.0)
            .padding(.bottom,0)
  
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
