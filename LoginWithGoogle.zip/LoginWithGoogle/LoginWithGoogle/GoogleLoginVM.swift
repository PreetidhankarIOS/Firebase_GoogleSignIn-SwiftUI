//
//  GoogleLoginVM.swift
//  LoginWithGoogle
//
//  Created by Ashish Viltoriya on 30/12/23.
//

import SwiftUI
import Firebase
import GoogleSignIn


    
    class UserAuthModel: ObservableObject {
        
        @Published var givenName: String = ""
        @Published var profilePicUrl: String = ""
        @Published var isLoggedIn: Bool = false
        @Published var errorMessage: String = ""
        
        init(){
            check()
        }
        
        func checkStatus(){
            if(GIDSignIn.sharedInstance.currentUser != nil){
                let user = GIDSignIn.sharedInstance.currentUser
                guard let user = user else { return }
                let givenName = user.profile?.givenName
                let profilePicUrl = user.profile!.imageURL(withDimension: 100)!.absoluteString
                self.givenName = givenName ?? ""
                self.profilePicUrl = profilePicUrl
                self.isLoggedIn = true
            }else{
                self.isLoggedIn = false
                self.givenName = "Not Logged In"
                self.profilePicUrl =  ""
            }
        }
        
        func check(){
            GIDSignIn.sharedInstance.restorePreviousSignIn { user, error in
                if let error = error {
                    self.errorMessage = "error: \(error.localizedDescription)"
                }
                
                self.checkStatus()
            }
        }
        
       func signIn()async -> Bool{
            
               guard let clientID = FirebaseApp.app()?.options.clientID else {
                 fatalError("No client ID found in Firebase configuration")
               }
               let config = GIDConfiguration(clientID: clientID)
               GIDSignIn.sharedInstance.configuration = config

           guard let windowScene = await UIApplication.shared.connectedScenes.first as? UIWindowScene,
                 let window = await windowScene.windows.first,
                 let rootViewController = await window.rootViewController else {
                 print("There is no root view controller!")
                 return false
               }

                 do {
                   let userAuthentication = try await GIDSignIn.sharedInstance.signIn(withPresenting: rootViewController)

                   let user = userAuthentication.user
                   let idToken = user.idToken
                   let accessToken = user.accessToken

                   let credential = GoogleAuthProvider.credential(withIDToken: idToken?.tokenString ?? "",
                                                                  accessToken: accessToken.tokenString)

                   let result = try await Auth.auth().signIn(with: credential)
                   let firebaseUser = result.user
                    
                    if (firebaseUser.email == nil) {
                        isLoggedIn = true
                    }
                   print("User \(firebaseUser.uid) signed in with email \(firebaseUser.email ?? "unknown")")
                   return true
                 }
                 catch {
                   print(error.localizedDescription)
                   self.errorMessage = error.localizedDescription
                   return false
                 }
             
        }
        
        func signOut(){
            GIDSignIn.sharedInstance.signOut()
            self.checkStatus()
        }
    }
    
